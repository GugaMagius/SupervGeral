
var enviaEmail = require('../../services/enviaEmail');
var main = require('../../../main')
var bd = require('../../BD/server')
const contatos = require('../../../contatos');


// Inicializa variáveis para tentativas de conexão
var envioEmail = false;
var tentatConex = 0;
var vReconectar = '';
var flagConnect = false;


console.log("INICIANDO Modbus")

// create an empty modbus client
var ModbusTCP = require("modbus-serial");
const e = require('cors');
var client = new ModbusTCP();

var networkErrors = ["ESOCKETTIMEDOUT", "ETIMEDOUT", "ECONNRESET", "ECONNREFUSED", "EHOSTUNREACH"];

// CONEXÃO COM O MODULO I/O ADAM WISE
function conectar() {
    // open connection to a tcp line 
    try {
        client.connectTCP("10.41.1.222")
            .then(client.setID(1))
            .then(function () {
                console.log("Connected");
                flagConnect = true;
                tentatConex = 0;
                clearTimeout(vReconectar);
                iniciarVariaveis();
            })
            .catch(function (e) {
                reconectar();
                if (e.errno) {
                    if (networkErrors.includes(e.errno)) {
                        let msgErro = "FALHA AO CONECTAR AO MÓDULO MODBUS" + e.errno
                        if (flagConnect === true) {
                            flagConnect = false;
                            bd.insertBD("log", msgErro)
                        }
                        console.log(msgErro)
                    }
                }
                let msgErro = "FALHA AO CONECTAR AO MÓDULO MODBUS" + e;
                if (flagConnect === true) {
                    flagConnect = false;
                    bd.insertBD("log", msgErro)
                }
                console.log(msgErro)
            });
    } catch (err) {
        let msgErro = "FALHA AO CONECTAR AO MÓDULO MODBUS" + err;
        if (flagConnect === true) {
            flagConnect = false;
            bd.insertBD("log", msgErro)
        }
        console.log(msgErro)
    }

}

try {
    conectar()
} catch (err) {
    console.log("Falha ao conectar ao módulo Adam! tentativa: ", tentatConex)
    let msgErro = "Falha ao conectar ao módulo Adam! tentativa: " + tentatConex + " - Erro número: " + err
    bd.insertBD("log", msgErro)
    console.log(msgErro)

    if (tentatConex > 60) {
        try {
            enviaEmail( // Chama função e envia e-mail
                "Leitura de Variáveis",
                "Falha ao conectar ao Modbus " + e.message,
                contatos.administrador.nome,
                contatos.administrador.email

            );
            tentatConex = 0;
        } catch (err) {
            let msgErro = "FALHA AO ENVIAR E-MAIL: " + err;
            bd.insertBD("log", msgErro)
            console.log(msgErro)
        }
    } else {

        tentatConex = tentatConex + 1;

    }
}

function reconectar() {
    vReconectar = setTimeout(conectar, 60000) // Tentar reconectar após 60 segundos
}

// ROTINA PARA DESCONECTAR O MÓDULO
function desconectar() {
    try {
        console.log("Desconectando I/O... ")
        client.destroy("10.41.1.222");
        console.log("I/O Desconectado!")
    } catch (err) {
        let msgErro = "FALHA AO DESCONECTAR AO CLP MÓDULO MODBUS" + err
        bd.insertBD("log", msgErro)
        console.log(msgErro)
    }
    reconectar()

}


// ROTINA PARA AQUISIÇÃO DOS VALORES (SETINTERVAL)
function adquireValor(iVariavel) {

    var leitura = setInterval(readAI, iVariavel[1].periodoAq)

    function readAI() {

        try {
            client.readHoldingRegisters(0, 7).then(
                function (valor) {
                    //console.log("Valor obtido do Modbus - Caixa d`água do refeitório: ", valor.data[iVariavel[1]["endereco"]])
                    main.tratDados(iVariavel, valor.data[iVariavel[1]["endereco"]]);

                }
            )
                .catch(function (e) {
                    clearInterval(leitura)
                    desconectar();
                    let msgErro = "ERRO AO TRATAR VARIÁVEL DO MODBUS: " + e.message
                    bd.insertBD("log", msgErro)
                    console.log(msgErro)
                })

        } catch (err) {
            clearInterval(leitura)
            let msgErro = "ERRO AO FAZER A LEITURA DA VARIÁVEL DO MODBUS: " + e.message
            bd.insertBD("log", msgErro)
            console.log(msgErro)
            enviaEmail( // Chama função e envia e-mail
                "Leitura de Variáveis",
                msgErro,
                contatos.administrador.nome,
                contatos.administrador.email
            );
        }

    }

}


// LEITURA DAS VARIAVEIS DO MODBUS
function iniciarVariaveis() {
    // Varre variáveis para aquisção com o CLP
    try {
        main.listaAtualizada().then(
            function (val) {
                var Variaveis = val
                console.log("INICIANDO FOR PARA VARIAVEIS DO MODBUS: " + JSON.stringify(Variaveis))
                for (const Variavel of Object.entries(Variaveis)) {
                    if (Variavel[1].modulo === "WISE1") {
                        console.log("Modulo: " + JSON.stringify(Variavel[1]))
                        adquireValor(Variavel)
                    }
                    //iniciarBD(Variavel)
                    //console.log("MENSAGEM ENVIADA: "+Variavel[1].mensagem)
                }
                //console.log("LISTA DE VARIAVEIS: " + JSON.stringify(val))
                return val
            }
        )
    } catch (err) {
        let msgErro = "ERRO AO ATUALIZAR VARIÁVEL DO MODBUS: " + e.message
        bd.insertBD("log", msgErro)
        console.log(msgErro)
    }

}
