<template>
  <div ref="falha">
    <h1>FALHA DE COMUNICAÇÃO COM O SERVIDOR</h1>
    <br />
    <h4>Verificar o funcionamento do servidor</h4>
  </div>
</template>
<script>

</script>
<style scoped>
#falha {
    width: 100%;
}
</style>




